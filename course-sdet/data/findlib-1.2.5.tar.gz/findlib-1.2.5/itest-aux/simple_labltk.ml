open Tk;;

let _ = openTk() in 
update();
closeTk()
;;

print_string "OK\n"
;;

